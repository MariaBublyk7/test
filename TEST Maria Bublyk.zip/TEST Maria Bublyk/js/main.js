// function to set a given theme/color-scheme
function setTheme(themeName) {
    localStorage.setItem('theme', themeName);
    document.documentElement.className = themeName;
}

// function to toggle between light and dark theme
function toggleTheme() {
    if (localStorage.getItem('theme') === 'theme-light') {
        setTheme('theme-dark');
    } else {
        setTheme('theme-light');
    }
}

// Immediately invoked function to set the theme on initial load
(function () {
    if (localStorage.getItem('theme') === 'theme-light') {
        setTheme('theme-light');
        document.getElementById('slider').checked = false;
    } else {
        setTheme('theme-dark');
      document.getElementById('slider').checked = true;
    }
})();


// Widget bar value
let number = 
    document.getElementsByClassName("number");
let output = 
    document.getElementById("output");

// Funtion to update rating
function gfg(n) {
    remove();
    for (let i = 0; i < n; i++) {
        if (n == 1) cls = "color";
        else if (n == 2) cls = "color";
        else if (n == 3) cls = "color";
        else if (n == 4) cls = "color";
        else if (n == 5) cls = "color";
        else if (n == 6) cls = "color";
        else if (n == 7) cls = "color";
        else if (n == 8) cls = "color";
        else if (n == 9) cls = "color";
        else if (n == 10) cls = "color";
        number[i].className = "number " + cls;
    }
    output.innerText = n;
}
 
// To remove 
function remove() {
    let i = 0;
    while (i < 10) {
        number[i].className = "number";
        i++;
    }
}